if not P1 or not P2 then
	backToSongWheel('Two Player Mode Required')
	return
end

-- judgment / combo proxies
for pn = 1, 2 do
	setupJudgeProxy(PJ[pn], P[pn]:GetChild('Judgment'), pn)
	setupJudgeProxy(PC[pn], P[pn]:GetChild('Combo'), pn)
end
-- player proxies
for pn = 1, #PP do
	PP[pn]:SetTarget(P[pn])
	P[pn]:hidden(1)
end


--helper functions and tablesfor stuff I wanna do

--set areas where we do wiggling!
function addWiggle(start, slowStart, finish)
	set {start, 50, 'beat'}
	for i = start, slowStart, 2 do
		ease {i-0.25, 0.5, inCubic, -40, 'movey0'}
		ease {i-0.25, 0.5, inCubic, -20, 'movey1'}
		ease {i+0.75, 0.5, outCubic, 40, 'movey0'}
		ease {i+0.75, 0.5, outCubic, 20, 'movey1'}
		ease {i+0.75, 0.5, inCubic, -20, 'movey2'}
		ease {i+0.75, 0.5, inCubic, -40, 'movey3'}
		ease {i+1.75, 0.5, outCubic, 20, 'movey2'}
		ease {i+1.75, 0.5, outCubic, 40, 'movey3'}
	end
	set {slowStart, 50, 'beatPeriod'}
	for i = slowStart, finish-1, 1 do
		ease {i-0.25, 0.25, inCubic, -40, 'movey0'}
		ease {i-0.25, 0.25, inCubic, -20, 'movey1'}
		ease {i+0.25, 0.25, outCubic, 40, 'movey0'}
		ease {i+0.25, 0.25, outCubic, 20, 'movey1'}
		ease {i+0.25, 0.25, inCubic, -20, 'movey2'}
		ease {i+0.25, 0.25, inCubic, -40, 'movey3'}
		ease {i+0.75, 0.25, outCubic, 20, 'movey2'}
		ease {i+0.75, 0.25, outCubic, 40, 'movey3'}
	end
	ease {finish, 0.25, inCubic, 0, 'movey0'}
	ease {finish, 0.25, inCubic, 0, 'movey1'}
	ease {finish, 0.25, inCubic, 0, 'movey2'}
	ease {finish, 0.25, inCubic, 0, 'movey3'}
	ease {finish, 5, linear, 0, 'beat'}
	set {finish+5, 100, 'beatPeriod'}
end

--do a spin!
function addSpin(beat)
	ease {beat, 5, outExpo, 720, 'rotationy'}
	set {beat+5, 0, 'rotationy'}
end

--set areas where we're bouncing!
function addBounce(start, finish)
	ease {start, 0.5, outCirc, -75, 'movey'}
	ease {start+0.5, 0.5, outCirc, 0, 'movey'}
	func_ease {start, 1, bounce, 1, 1.05, function(v)
		wwf_bg:zoomtowidth(SCREEN_WIDTH * v)
		wwf_bg:zoomtoheight(SCREEN_HEIGHT * v)
	end }
	for i = start+1, finish do
		bounceValue = 1
		bounceHeight = -75
		if i % 2 ~= 0 then bounceValue = -1 end
		ease {i, 0.5, linear, bounceValue*50, 'movex'}
		ease {i, 0.5, outCirc, -50, 'movey'}
		ease {i, 0.5, linear, bounceValue*10, 'rotationz'}
		ease {i+0.5, 0.5, linear, 0, 'movex'}
		ease {i+0.5, 0.5, outCirc, 0, 'movey'}
		ease {i+0.5, 0.5, linear, 0, 'rotationz'}
		func_ease {i, 1, bounce, 1, 1.05, function(v)
			wwf_bg:zoomtowidth(SCREEN_WIDTH * v)
			wwf_bg:zoomtoheight(SCREEN_HEIGHT * v)
		end }
	end
end

--add bump-out effects to the vocal licks - small and large versions!
function addBumps(table)
	beat = table[1]
	for i = 2, #table do
		duration = table[i]
		ease {beat, duration, outBack, 8000*duration, 'zoomz'}
		ease {beat+duration, duration, outBack, 100, 'zoomz'}
		beat = beat+(2*duration)
	end
end

--add a Y-spin to the drum fills!
function addFill(beat)
	ease {beat, 0.5, outCubic, 30, 'rotationy'}
	ease {beat+0.5, 0.5, outCubic, -30, 'rotationy'}
	ease {beat+1, 0.5, outCubic, 30, 'rotationy'}
	ease {beat+2, 0.5, outCubic, -30, 'rotationy'}
	ease {beat+2.5, 0.5, outCubic, 30, 'rotationy'}
	ease {beat+3, 0.5, outCubic, 0, 'rotationy'}
end

--add stretch effects to holds/rolls in the 3-pattern!
function addStretchHolds(beats)
	for _, beat in ipairs(beats) do
		ease {beat, 0.5, linear, 140, 'zoomy'}
		ease {beat+0.5, 0.5, linear, 100, 'zoomy'}
	end
end

function addStretchRoll(beat)
	ease {beat, 0.25, linear, 120, 'zoomy'}
	ease {beat+0.25, 0.25, linear, 100, 'zoomy'}
	ease {beat+0.5, 0.25, linear, 120, 'zoomy'}
	ease {beat+0.75, 0.25, linear, 100, 'zoomy'}
end

--add the slide-in for when the precussion drops out! (thanks taro)
function addSlide(beat)
	ease {beat, 2, outCubic, 40, 'brake'}
	ease {beat, 2, outCubic, 60, 'drunk'}
	ease {beat+2, 1.5, inCubic, 0, 'brake'}
	ease {beat+2, 1.5, inCubic, 0, 'drunk'}
end

--add the big jump!
function addJump(beat)
	ease {beat, 0.5, outQuad, 150, 'zoom'}
	ease {beat+0.5, 0.5, inQuad, 100, 'zoom'}
end

--add the stealth/flip squish effect!
function addSquish(beat)
	ease {beat, 0.25, outBack, 20, 'stealth'}
	ease {beat, 0.25, outBack, 10, 'flip'}
	ease {beat+0.5, 0.25, outBack, 10, 'stealth'}
	ease {beat+0.5, 0.25, outBack, 0, 'flip'}
	ease {beat+1, 0.125, outBack, 20, 'stealth'}
	ease {beat+1, 0.125, linear, 10, 'flip'}
	ease {beat+1.125, 0.125, outBack, 0, 'stealth'}
	ease {beat+1.125, 0.125, linear, 0, 'flip'}
	ease {beat+5, 0.25, outBack, 20, 'stealth'}
	ease {beat+5, 0.25, outBack, 10, 'flip'}
	ease {beat+5.5, 0.25, outBack, 0, 'stealth'}
	ease {beat+5.5, 0.25, outBack, 0, 'flip'}
end

--let's begin!

--maybe move rotationx and rotationz away if I need to use a reset
setdefault {2, 'xmod', 40, 'rotationx', -60, 'rotationz', 100, 'dark', 150, 'zigzagperiod', 10, 'drawsize'}

--cool chill intro segment
ease {-0.5, 0.5, inCubic, 0, 'dark'}
ease {0, 16, inOutCirc, -40, 'rotationx'}
ease {0, 16, inOutCirc, 60, 'rotationz'}
ease {16, 16, inOutCirc, 0, 'rotationx'}
ease {16, 16, inOutCirc, 0, 'rotationz'}

--gentle zigzags to start out
set {16, 25, 'zigzag'}

--appearance of cuddlebot!
func{64,function()

	char_lemma:basezoomx(.6)
	char_lemma:basezoomy(.6)
	
	char_lemma:x(SCREEN_CENTER_X)
	char_lemma:y(SCREEN_CENTER_Y)
	char_lemma:queuecommand('Spawn')
end}

--column wiggles!
ease {64, 2, linear, 0, 'zigzag'}
addWiggle(64, 80, 88)

--*vinny voice* speeeen! (and cast)
addSpin(88)

func{88,function()
	char_lemma:queuecommand('CastFX')
	char_lemma:queuecommand('Cast')
end}

--big bouncing and some bumps!
func{96, function()
	char_lemma:queuecommand('Hide')
end}
addBounce(96, 123)
addBumps {119, 0.25, 0.125, 0.125}
addFill(124)
addBounce(128, 151)
addBumps {140, 0.25, 0.125, 0.125, 0.25, 0.25}

--stretchies on the triple holds!
addStretchHolds {133, 134, 135}
addStretchHolds {149, 151}
addStretchRoll(150)
addSlide(152)

--BIG jump!
addJump(160)
addBounce(161, 187)
addBumps {175, 0.25, 0.125, 0.125}
addSquish(178)
addSlide(188)
addBumps {190, 0.25, 0.25, 0.25}
addBounce(192, 214)

--more stretchies!
addStretchHolds {197, 198, 199}
addBumps {206, 0.25, 0.25, 0.25, 0.25}
addStretchHolds {213, 214, 215}
addSlide(216)

--Speen to fade out!
addSpin(224)
ease {224, 4, outExpo, 100, 'dark'}

--after a bit of time faded, come back in!
set {229, 40, 'rotationx'}
set {229, 60, 'rotationz'}
ease {238, 4, inExpo, 0, 'dark'}
ease {236, 12, inOutCirc, -40, 'rotationx'}
ease {236, 12, inOutCirc, -60, 'rotationz'}
ease {248, 8, inOutCirc, 0, 'rotationx'}
ease {248, 8, inOutCirc, 0, 'rotationz'}

func{254,function()
	char_lemma:queuecommand('Idle')
	char_lemma:queuecommand('Spawn')
end}

--back to wigglies!
addWiggle(256, 272, 280)

--another spin before...
func{280,function()
	char_lemma:queuecommand('Cast')
end}
addSpin(280)

--we go back into the main bounce!
func{288, function()
	char_lemma:queuecommand('Hide')
end}
addBounce(288, 315)

--a little zig
set {302, 100, 'zigzag'}
set {304, 0, 'zigzag'}
addBumps {311, 0.25, 0.125, 0.125}
addFill(316)

--more bouncing with some stretches and a little zag
addBounce(320, 343)
addStretchHolds {325, 326, 327}
addBumps {332, 0.25, 0.125, 0.125, 0.25, 0.25}
set {334, 100, 'zigzag'}
set {336, 0, 'zigzag'}
addStretchHolds {341, 343}
addStretchRoll(342)
addSlide(344)

--JUMP! (and another tilt)
addJump(352)
addBounce(353, 379)
addBumps {367, 0.25, 0.125, 0.125}
addSquish(370)
addSlide(380)
addBumps {382, 0.25, 0.25, 0.25}
addBounce(384, 407)
addStretchHolds {389, 390, 391}
addBumps {398, 0.25, 0.125, 0.125, 0.25, 0.25}
addStretchHolds {405, 406, 407}
addSlide(408)
func {408, function()
	char_lemma:queuecommand('Spawn')
end}

addBumps {413, 0.25, 0.125, 0.125, 0.25, 0.25, 0.25}

--and one last spin to finish it off!
func {415.9, function()
	char_lemma:queuecommand('Win')
end}
addSpin(416)
func_ease {420, 16, linear, 0, 0.9, function(v)
	wwf_fadeout:diffuse(0, 0, 0, v)
end}